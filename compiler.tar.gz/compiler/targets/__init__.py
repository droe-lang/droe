"""Target-specific code generators for Roelang compiler.

This package contains code generators for different compilation targets
such as WebAssembly, native code, and other platforms.
"""