"""Rust target with Axum/database code generation."""

from .codegen import RustCodeGenerator

__all__ = ['RustCodeGenerator']