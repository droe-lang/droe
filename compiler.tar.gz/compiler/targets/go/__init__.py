"""Go target for Roelang compiler.

This module provides Go-specific code generation functionality.
"""