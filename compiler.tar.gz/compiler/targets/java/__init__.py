"""Java target for Roelang compiler.

This module provides Java-specific code generation functionality.
"""