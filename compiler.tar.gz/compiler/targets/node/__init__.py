"""Node.js target for Roelang compiler.

This module provides Node.js-specific code generation functionality.
"""