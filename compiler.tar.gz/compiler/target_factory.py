"""Target factory for Roelang compiler.

This module provides a factory system for creating target-specific
code generators and managing compilation targets.
"""

from typing import Dict, Type, Optional, List, Any
from abc import ABC, abstractmethod
from pathlib import Path
from .codegen_base import BaseCodeGenerator
from .ast import Program


class CompilerTarget(ABC):
    """Abstract base class for compilation targets."""
    
    def __init__(self, name: str, file_extension: str, description: str):
        self.name = name
        self.file_extension = file_extension
        self.description = description
    
    @abstractmethod
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain") -> BaseCodeGenerator:
        """Create a code generator for this target."""
        pass
    
    @abstractmethod
    def get_runtime_files(self) -> List[str]:
        """Get list of runtime files needed for this target."""
        pass
    
    @abstractmethod
    def get_dependencies(self) -> List[str]:
        """Get list of external dependencies for this target."""
        pass


class WASMTarget(CompilerTarget):
    """WebAssembly compilation target."""
    
    def __init__(self):
        super().__init__("wasm", ".wasm", "WebAssembly binary format")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain") -> BaseCodeGenerator:
        from .targets.wasm.codegen import WATCodeGenerator
        return WATCodeGenerator()
    
    def get_runtime_files(self) -> List[str]:
        return ["run.js"]
    
    def get_dependencies(self) -> List[str]:
        return ["node", "wat2wasm"]


class PythonTarget(CompilerTarget):
    """Python compilation target."""
    
    def __init__(self):
        super().__init__("python", ".py", "Python source code")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain", package: Optional[str] = None, database: Optional[Dict[str, Any]] = None) -> BaseCodeGenerator:
        from .targets.python.codegen import PythonCodeGenerator
        return PythonCodeGenerator(source_file_path, is_main_file, framework, package, database)
    
    def get_runtime_files(self) -> List[str]:
        return []  # No runtime files needed - using inline code generation
    
    def get_dependencies(self) -> List[str]:
        return ["python3"]


class JavaTarget(CompilerTarget):
    """Java compilation target."""
    
    def __init__(self):
        super().__init__("java", ".java", "Java source code")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain", package: Optional[str] = None, database: Optional[Dict[str, Any]] = None) -> BaseCodeGenerator:
        from .targets.java.codegen import JavaCodeGenerator
        return JavaCodeGenerator(source_file_path, is_main_file, framework, package, database)
    
    def get_runtime_files(self) -> List[str]:
        return []  # No runtime files needed - using inline code generation
    
    def get_dependencies(self) -> List[str]:
        return ["javac", "java"]


class HTMLTarget(CompilerTarget):
    """HTML/JavaScript compilation target."""
    
    def __init__(self):
        super().__init__("html", ".html", "HTML with embedded JavaScript")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain") -> BaseCodeGenerator:
        from .targets.html.codegen import HTMLCodeGenerator
        return HTMLCodeGenerator()
    
    def get_runtime_files(self) -> List[str]:
        return ["roelang.js", "styles.css"]
    
    def get_dependencies(self) -> List[str]:
        return []  # Runs in browser, no external deps


# Note: Kotlin and Swift targets have been replaced by the mobile target
# which generates complete Android (Kotlin) and iOS (Swift) projects.
# Use @metadata(platform="mobile") or @targets "android, ios" instead.


class GoTarget(CompilerTarget):
    """Go compilation target."""
    
    def __init__(self):
        super().__init__("go", ".go", "Go source code")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain", package: str = None, database_config: Dict = None) -> BaseCodeGenerator:
        from .targets.go.codegen import GoCodeGenerator
        return GoCodeGenerator(framework=framework, database_config=database_config, package=package)
    
    def get_runtime_files(self) -> List[str]:
        return []  # No runtime files needed - using inline code generation
    
    def get_dependencies(self) -> List[str]:
        return ["go"]


class NodeTarget(CompilerTarget):
    """Node.js compilation target."""
    
    def __init__(self):
        super().__init__("node", ".js", "Node.js JavaScript code")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain", package: Optional[str] = None, database: Optional[Dict[str, Any]] = None) -> BaseCodeGenerator:
        from .targets.node.codegen import NodeCodeGenerator
        return NodeCodeGenerator(source_file_path, is_main_file, framework, package, database)
    
    def get_runtime_files(self) -> List[str]:
        return []  # No runtime files needed - using inline code generation
    
    def get_dependencies(self) -> List[str]:
        return ["node", "npm"]


class BytecodeTarget(CompilerTarget):
    """Bytecode compilation target for Droe VM."""
    
    def __init__(self):
        super().__init__("bytecode", ".droebc", "Droe VM bytecode format")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain") -> BaseCodeGenerator:
        from .targets.bytecode.codegen import BytecodeGenerator
        return BytecodeGenerator()
    
    def get_runtime_files(self) -> List[str]:
        return []  # VM is bundled separately
    
    def get_dependencies(self) -> List[str]:
        return ["droevm"]  # Requires the Droe VM


class MobileTarget(CompilerTarget):
    """Mobile compilation target - generates Android and iOS projects."""
    
    def __init__(self):
        super().__init__("mobile", ".mobile", "Mobile platforms (Android + iOS)")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain") -> BaseCodeGenerator:
        # Mobile target generates complete project structures
        from .targets.mobile.codegen import MobileProjectCodegen
        
        # Find project root by looking for roeconfig.json
        project_root = None
        if source_file_path:
            current_dir = Path(source_file_path).parent
            for _ in range(10):  # Search up to 10 levels
                if (current_dir / "roeconfig.json").exists():
                    project_root = str(current_dir)
                    break
                parent = current_dir.parent
                if parent == current_dir:
                    break
                current_dir = parent
        
        return MobileProjectCodegen(source_file_path, project_root)
    
    def get_runtime_files(self) -> List[str]:
        return []  # Mobile projects are complete standalone projects
    
    def get_dependencies(self) -> List[str]:
        return ["android-sdk", "xcode"]  # Development environment dependencies


class RustTarget(CompilerTarget):
    """Rust compilation target - generates standard Rust code with Axum and database support."""
    
    def __init__(self):
        super().__init__("rust", ".rs", "Rust with Axum/database support")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, 
                      framework: str = "axum", package: Optional[str] = None, 
                      database: Optional[Dict[str, Any]] = None) -> BaseCodeGenerator:
        from .targets.rust.codegen import RustCodeGenerator
        
        # Load database config from roeconfig.json if available
        if source_file_path and not database:
            database = self._load_database_config(source_file_path)
            
        return RustCodeGenerator(source_file_path, is_main_file, framework, package, database)
    
    def _load_database_config(self, source_file_path: str) -> Dict[str, Any]:
        """Load database configuration from roeconfig.json."""
        import json
        from pathlib import Path
        
        current_dir = Path(source_file_path).parent
        for _ in range(10):  # Search up to 10 levels
            config_path = current_dir / "roeconfig.json"
            if config_path.exists():
                try:
                    with open(config_path, 'r') as f:
                        config = json.load(f)
                        return config.get('database', {})
                except Exception:
                    pass
            parent = current_dir.parent
            if parent == current_dir:
                break
            current_dir = parent
        
        return {}
    
    def get_runtime_files(self) -> List[str]:
        return []  # Rust projects are standalone
    
    def get_dependencies(self) -> List[str]:
        return ["cargo", "rustc"]  # Rust toolchain


class DroeTarget(CompilerTarget):
    """Native DroeVM compilation target - generates DroeVM bytecode."""
    
    def __init__(self):
        super().__init__("droe", ".droebc", "Native DroeVM bytecode")
    
    def create_codegen(self, source_file_path: str = None, is_main_file: bool = False, 
                      framework: str = "plain", package: Optional[str] = None, 
                      database: Optional[Dict[str, Any]] = None) -> BaseCodeGenerator:
        from .targets.bytecode.codegen import BytecodeGenerator
        return BytecodeGenerator()
    
    def get_runtime_files(self) -> List[str]:
        return []  # DroeVM handles bytecode execution
    
    def get_dependencies(self) -> List[str]:
        return ["droevm"]  # Requires the DroeVM runtime


class TargetFactory:
    """Factory for creating compilation targets."""
    
    def __init__(self):
        self._targets: Dict[str, Type[CompilerTarget]] = {
            "wasm": WASMTarget,
            "python": PythonTarget,
            "java": JavaTarget,
            "html": HTMLTarget,
            "go": GoTarget,
            "node": NodeTarget,
            "bytecode": BytecodeTarget,
            "mobile": MobileTarget,
            "rust": RustTarget,
            "droe": DroeTarget
        }
    
    def get_available_targets(self) -> List[str]:
        """Get list of available compilation targets."""
        return list(self._targets.keys())
    
    def create_target(self, target_name: str) -> CompilerTarget:
        """Create a compilation target by name."""
        if target_name not in self._targets:
            # Provide helpful migration message for removed targets
            if target_name in ['kotlin', 'swift']:
                raise ValueError(
                    f"Target '{target_name}' has been replaced by the mobile target. "
                    f"Use @metadata(platform=\"mobile\") or @targets \"android, ios\" instead. "
                    f"See MOBILE_MIGRATION.md for details."
                )
            
            available = ", ".join(self.get_available_targets())
            raise ValueError(f"Unknown target '{target_name}'. Available: {available}")
        
        return self._targets[target_name]()
    
    def register_target(self, name: str, target_class: Type[CompilerTarget]):
        """Register a new compilation target."""
        self._targets[name] = target_class
    
    def get_target_info(self, target_name: str) -> Dict[str, any]:
        """Get information about a compilation target."""
        target = self.create_target(target_name)
        return {
            "name": target.name,
            "file_extension": target.file_extension,
            "description": target.description,
            "runtime_files": target.get_runtime_files(),
            "dependencies": target.get_dependencies()
        }


# Global factory instance
target_factory = TargetFactory()


def compile_to_target(program: Program, target_name: str, source_file_path: str = None, is_main_file: bool = False, framework: str = "plain", package: Optional[str] = None, database: Optional[Dict[str, Any]] = None):
    """Compile a program to a specific target."""
    target = target_factory.create_target(target_name)
    
    # Special handling for targets that need database config
    if target_name == 'rust':
        codegen = target.create_codegen(source_file_path, is_main_file, framework, package, database)
    elif target_name == 'java':
        codegen = target.create_codegen(source_file_path, is_main_file, framework, package, database)
    elif target_name == 'python':
        codegen = target.create_codegen(source_file_path, is_main_file, framework, package, database)
    elif target_name == 'node':
        codegen = target.create_codegen(source_file_path, is_main_file, framework, package, database)
    elif target_name == 'go':
        codegen = target.create_codegen(source_file_path, is_main_file, framework, package, database)
    else:
        codegen = target.create_codegen(source_file_path, is_main_file, framework)
    
    result = codegen.generate(program)
    
    # Handle Spring Boot projects and other multi-file results
    if isinstance(result, dict) and 'files' in result:
        # Create the actual files
        _create_project_files(result, source_file_path)
        return result
    
    return result


def _create_project_files(project_result: Dict[str, Any], source_file_path: str = None):
    """Create actual files from a project result dictionary."""
    import os
    import json
    from pathlib import Path
    
    files = project_result.get('files', {})
    project_root_name = project_result.get('project_root', 'generated_project')
    
    # Find project root and load config (like mobile target does)
    if source_file_path:
        project_root_dir = Path(source_file_path).parent
    else:
        project_root_dir = Path.cwd()
    
    # Look for roeconfig.json up to 10 levels up
    config_dir = project_root_dir
    config = {}
    for _ in range(10):
        config_path = config_dir / "roeconfig.json"
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                project_root_dir = config_dir
                break
            except Exception:
                pass
        parent = config_dir.parent
        if parent == config_dir:
            break
        config_dir = parent
    
    # Use build directory from config (like mobile target)
    build_dir = project_root_dir / config.get('build', 'build')
    base_dir = build_dir / project_root_name
    
    # Create project directory
    base_dir.mkdir(parents=True, exist_ok=True)
    
    # Create all files
    for file_path, content in files.items():
        full_path = base_dir / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    
    print(f"✅ Created {len(files)} files in {base_dir}")
    return str(base_dir)


def get_target_codegen(target_name: str, source_file_path: str = None, is_main_file: bool = False) -> BaseCodeGenerator:
    """Get a code generator for a specific target."""
    target = target_factory.create_target(target_name)
    return target.create_codegen(source_file_path, is_main_file)