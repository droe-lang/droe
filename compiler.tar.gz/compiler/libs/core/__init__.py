"""Core runtime libraries for Roelang.

This module provides the core runtime functionality that is available
to all Roelang programs by default.
"""