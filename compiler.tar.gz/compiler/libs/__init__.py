"""Core libraries for Roelang compiler.

This package contains core runtime libraries that provide built-in functionality
for string operations, math operations, formatting, and other essential features.
"""